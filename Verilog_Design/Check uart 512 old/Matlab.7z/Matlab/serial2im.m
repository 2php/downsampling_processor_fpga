fpga = serial('COM3');
fpga.InputBufferSize = 10000000;
fpga.OutputBufferSize = 10000000;
fpga.BaudRate = 115200;

fclose(instrfind);
fopen(fpga);

fpga.Timeout = 60;                  % One minute timeout period

im_received = fread(fpga,65536);%65536
fclose(instrfind);

% im_array = zeros(65536,1);
 im_out = reshape(im_received', [256,256]);
 imshow(uint8(im_out));